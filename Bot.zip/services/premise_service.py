from models.premise import Premise


class PremiseService:


    def __init__(
        self,
        repository
    ):

        self.repository = repository



    def free_list(self):

        """
        Возвращает список свободных помещений
        """

        return self.repository.get_free()



    def get(
        self,
        premise_id
    ):

        """
        Получение помещения по ID
        """

        return self.repository.get_by_id(
            premise_id
        )



    def card(
        self,
        premise: Premise
    ):

        """
        Карточка помещения
        """

        return f"""
🏢 {premise.title}

📌 Тип:
{premise.type}

📍 Здание:
{premise.building}

🏬 Этаж:
{premise.floor}

📐 Площадь:
{premise.area} м²

💰 Стоимость аренды:
{premise.price} руб./мес


{premise.description}


🟢 Статус:
Свободно
"""

    def format_card(
            self,
            premise
    ):

        text = []

        text.append(
            f"🏢 {premise.title}"
        )

        text.append("")

        text.append(
            f"📐 {premise.area:g} м²"
        )

        text.append(
            f"💰 {premise.price:,} ₽/мес"
            .replace(",", " ")
        )

        if premise.building:
            text.append(
                f"📍 {premise.building}"
            )

        if premise.floor:
            text.append(
                f"🏬 Этаж: {premise.floor}"
            )

        if premise.description:
            text.append("")

            text.append(
                f"🚪 {premise.description}"
            )

        text.append("")

        text.append(
            "🟢 Свободно"
        )

        return "\n".join(text)


    def count_free(self):

        """
        Количество свободных помещений
        """

        return len(
            self.free_list()
        )