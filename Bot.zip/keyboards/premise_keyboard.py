from maxapi.types import (
    Attachment,
    ButtonsPayload,
    CallbackButton,
)


def premise_keyboard(
    premise_id: int
):

    buttons = [

        [
            CallbackButton(
                text="📝 Подать заявку",
                payload=f"apply_{premise_id}"
            )
        ],

        [
            CallbackButton(
                text="⬅ К списку помещений",
                payload="premises"
            )
        ]

    ]


    return Attachment(

        type="inline_keyboard",

        payload=ButtonsPayload(

            buttons=buttons

        )

    )