import csv

from models.premise import Premise


class CsvRepository:


    def __init__(self, filename):

        self.filename = filename


    def get_all(self):

        result = []


        with open(
            self.filename,
            encoding="utf-8"
        ) as file:


            reader = csv.DictReader(file)


            for row in reader:


                result.append(

                    Premise(

                        id=int(row["id"]),

                        title=row["title"],

                        type=row["type"],

                        building=row["building"],

                        floor=int(row["floor"]),

                        area=float(row["area"]),

                        price=int(row["price"]),

                        status=row["status"],

                        description=row["description"]

                    )

                )


        return result



    def get_free(self):

        return [

            item

            for item in self.get_all()

            if item.status == "free"

        ]



    def get_by_id(self, item_id):

        for item in self.get_all():

            if item.id == item_id:

                return item


        return None