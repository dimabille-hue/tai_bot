from maxapi.types import MessageCallback


from config import PREMISES_FILE

from repository.csv_repository import CsvRepository

from services.premise_service import PremiseService

from keyboards.premise_keyboard import premise_keyboard

from keyboards.premises_list import premises_list_keyboard



repository = CsvRepository(
    PREMISES_FILE
)


service = PremiseService(
    repository
)



def register_callback_handlers(
    dp,
    bot
):


    @dp.message_callback()
    async def callback_handler(
        event: MessageCallback
    ):


        payload = event.callback.payload


        chat_id = event.chat.chat_id


        print(
            "PAYLOAD:",
            payload
        )



        # =====================================================
        # Список свободных помещений
        # =====================================================

        if payload == "premises":


            premises = service.free_list()


            if not premises:


                await bot.send_message(

                    chat_id=chat_id,

                    text=(
                        "Свободных помещений нет."
                    )

                )

                return



            await bot.send_message(

                chat_id=chat_id,

                text=(
                    "🏢 Свободные помещения\n\n"
                    "Выберите интересующее помещение:"
                ),

                attachments=[

                    premises_list_keyboard(
                        premises
                    )

                ]

            )


            return



        # =====================================================
        # Выбрано конкретное помещение
        # =====================================================

        if payload.startswith(
            "premise_"
        ):


            premise_id = int(

                payload.split("_")[1]

            )


            premise = service.get(

                premise_id

            )


            if not premise:


                await bot.send_message(

                    chat_id=chat_id,

                    text=(
                        "Помещение не найдено."
                    )

                )

                return



            await bot.send_message(

                chat_id=chat_id,

                text=service.format_card(

                    premise

                ),

                attachments=[

                    premise_keyboard(

                        premise.id

                    )

                ]

            )


            return



        # =====================================================
        # Следующее помещение (оставляем для совместимости)
        # =====================================================

        if payload.startswith(
            "next_"
        ):


            premises = service.free_list()


            index = int(

                payload.split("_")[1]

            )


            index += 1


            if index >= len(premises):

                index = 0



            premise = premises[index]



            await bot.send_message(

                chat_id=chat_id,

                text=service.format_card(

                    premise

                ),

                attachments=[

                    premise_keyboard(

                        premise.id

                    )

                ]

            )


            return



        # =====================================================
        # Заявка на аренду
        # =====================================================

        if payload.startswith(
            "apply_"
        ):


            premise_id = int(

                payload.split("_")[1]

            )


            premise = service.get(

                premise_id

            )


            if not premise:


                await bot.send_message(

                    chat_id=chat_id,

                    text=(
                        "Помещение не найдено."
                    )

                )

                return



            await bot.send_message(

                chat_id=chat_id,

                text=(

                    "📝 Заявка на аренду\n\n"

                    f"Помещение: {premise.title}\n"
                    f"Площадь: {premise.area} м²\n"
                    f"Стоимость: {premise.price} ₽/мес\n\n"

                    "Введите ваше имя и номер телефона."

                )

            )


            return



        # =====================================================
        # Документы
        # =====================================================

        if payload == "documents":


            await bot.send_message(

                chat_id=chat_id,

                text=(
                    "📄 Раздел документов\n\n"
                    "Здесь будут шаблоны договоров "
                    "и перечень необходимых документов."
                )

            )


            return



        # =====================================================
        # Контакты
        # =====================================================

        if payload == "contacts":


            await bot.send_message(

                chat_id=chat_id,

                text=(

                    "АО «ТомскАгроИнвест»\n\n"

                    "📍 г. Томск, пр. Фрунзе, 119/5\n"

                    "☎ +7 (3822) 24-43-10\n"

                    "☎ +7 913 855-52-23\n\n"

                    "Отдел аренды"

                )

            )


            return