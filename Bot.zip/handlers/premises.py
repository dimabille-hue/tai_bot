from maxapi.types import MessageCreated


from config import PREMISES_FILE

from repository.csv_repository import CsvRepository

from services.premise_service import PremiseService



repository = CsvRepository(
    PREMISES_FILE
)


service = PremiseService(
    repository
)



def register_premise_handlers(
    dp,
    bot
):


    @dp.message_created()
    async def premises_handler(
        event: MessageCreated
    ):

        text = event.message.body.text


        if text != "🏢 Свободные помещения":

            return


        premises = service.free_list()


        result = (
            "Свободные помещения:\n\n"
        )


        for item in premises:

            result += (

                f"{item.id}. "
                f"{item.title}\n"
                f"{item.area} м²\n"
                f"{item.price} руб./мес\n\n"

            )


        await bot.send_message(

            chat_id=event.chat.chat_id,

            text=result

        )