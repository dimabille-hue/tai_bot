from maxapi.types import (
    Attachment,
    ButtonsPayload,
    CallbackButton,
)



def premises_list_keyboard(
    premises
):

    buttons = []


    for item in premises:

        buttons.append(

            [
                CallbackButton(

                    text=(
                        f"{item.title} | "
                        f"{item.area} м²"

                    ),

                    payload=f"premise_{item.id}"

                )
            ]

        )


    return Attachment(

        type="inline_keyboard",

        payload=ButtonsPayload(

            buttons=buttons

        )

    )