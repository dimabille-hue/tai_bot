from pathlib import Path
import os

from dotenv import load_dotenv


load_dotenv()


BASE_DIR = Path(__file__).resolve().parent


BOT_TOKEN = os.getenv(
    "BOT_TOKEN"
)


DATA_DIR = BASE_DIR / "data"

DOCS_DIR = BASE_DIR / "docs"


PREMISES_FILE = DATA_DIR / "premises.csv"

APPLICATIONS_FILE = DATA_DIR / "applications.csv"