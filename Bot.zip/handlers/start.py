from maxapi.types import MessageCreated

from keyboards.main_menu import main_keyboard



def register_start_handlers(dp, bot):


    @dp.message_created()
    async def start_handler(
        event: MessageCreated
    ):

        text = ""

        if event.message.body:
            text = event.message.body.text or ""


        if text != "/start":
            return


        await bot.send_message(

            chat_id=event.chat.chat_id,

            text=(
                "Здравствуйте!\n\n"
                "Бот аренды помещений\n"
                "АО «ТомскАгроИнвест»\n\n"
                "Выберите нужный раздел:"
            ),

            attachments=[
                main_keyboard()
            ]

        )