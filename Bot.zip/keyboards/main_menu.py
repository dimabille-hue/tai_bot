from maxapi.types import (
    Attachment,
    ButtonsPayload,
    CallbackButton,
)


def main_keyboard():

    buttons = ButtonsPayload(
        buttons=[

            [
                CallbackButton(
                    text="🏢 Свободные помещения",
                    payload="premises"
                )
            ],

            [
                CallbackButton(
                    text="📝 Подать заявку",
                    payload="application"
                )
            ],

            [
                CallbackButton(
                    text="📄 Документы",
                    payload="documents"
                )
            ],

            [
                CallbackButton(
                    text="☎ Контакты",
                    payload="contacts"
                )
            ]
        ]
    )


    return Attachment(
        type="inline_keyboard",
        payload=buttons
    )