import asyncio

from maxapi import Bot, Dispatcher

from config import BOT_TOKEN

from handlers.start import register_start_handlers
from handlers.premises import register_premise_handlers
from handlers.callbacks import register_callback_handlers


bot = Bot(
    token=BOT_TOKEN
)

dp = Dispatcher()


def register_handlers():

    register_start_handlers(
        dp,
        bot
    )


    register_premise_handlers(
        dp,
        bot
    )


    register_callback_handlers(
        dp,
        bot
    )


async def main():

    register_handlers()

    print(
        "BOT STARTED"
    )


    await dp.start_polling(
        bot
    )



if __name__ == "__main__":

    asyncio.run(main())